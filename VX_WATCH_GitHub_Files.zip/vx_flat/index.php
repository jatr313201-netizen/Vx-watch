<?php
$colours = [
 ["Black","#111111"],["White","#e9eef2"],["Blue","#246bce"],["Red","#c93434"],["Green","#2e7d58"],
 ["Gold","#c7a54a"],["Silver","#aeb7c2"],["Orange","#df7b2d"],["Purple","#7546a8"],["Pink","#d77b9a"]
];
?>
<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>VX WATCH | VX Smart Watch</title>
<style>
*{box-sizing:border-box}body{margin:0;font-family:Arial,sans-serif;background:#f5f7fb;color:#101828}
.top{background:#07111f;color:#fff;text-align:center;padding:8px;font-size:13px}.nav{position:sticky;top:0;z-index:5;background:#fff;border-bottom:1px solid #e5e7eb;display:flex;justify-content:space-between;align-items:center;padding:15px 5%}.brand{font-size:24px;font-weight:900}.brand span{color:#0b72ff}.nav a{margin:0 12px;font-weight:700;font-size:14px}
.btn{border:0;border-radius:10px;padding:13px 19px;font-weight:800;cursor:pointer}.dark{background:#07111f;color:#fff}.blue{background:#0b72ff;color:#fff}
.hero{background:linear-gradient(135deg,#06101e,#123c67);color:#fff;padding:70px 5%;display:grid;grid-template-columns:1fr 1fr;gap:45px;align-items:center}.hero h1{font-size:58px;line-height:1;margin:10px 0}.hero p{font-size:18px;line-height:1.6;color:#dbe7f3;max-width:560px}.price{font-size:38px;font-weight:900;margin:20px 0}.watch{width:245px;height:315px;background:#0b0d10;border-radius:55px;margin:auto;padding:25px 18px;box-shadow:0 25px 65px #0009}.screen{height:265px;border-radius:35px;background:radial-gradient(circle at 55% 30%,#194775,#02060a 70%);display:flex;flex-direction:column;justify-content:center;align-items:center;font-weight:900;font-size:24px}.screen small{font-size:11px;color:#9fb4ca;margin-top:8px}
.wrap{max-width:1180px;margin:auto;padding:65px 5%}.title{text-align:center;font-size:34px;margin:0 0 10px}.sub{text-align:center;color:#667085;margin:0 auto 35px}.features{display:grid;grid-template-columns:repeat(4,1fr);gap:16px}.feature,.product,.box{background:#fff;border:1px solid #e5e7eb;border-radius:17px;padding:22px}.feature{text-align:center}.feature b{display:block;margin:8px}.products{display:grid;grid-template-columns:repeat(5,1fr);gap:15px}.product{padding:13px}.visual{height:190px;border-radius:14px;display:flex;align-items:center;justify-content:center}.mini{width:88px;height:130px;background:#101010;border-radius:22px;padding:9px}.mini div{height:112px;border-radius:15px;background:#071019;color:#fff;display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:900;text-align:center}.product h3{margin:12px 2px 4px}.row{display:flex;justify-content:space-between;align-items:center}.add{width:100%;margin-top:10px;background:#07111f;color:#fff;border:0;border-radius:9px;padding:11px;font-weight:800;cursor:pointer}
.checkout{display:grid;grid-template-columns:1fr 400px;gap:22px}.box h3{margin-top:0}label{display:block;font-size:14px;font-weight:700;margin:13px 0 6px}input,textarea,select{width:100%;padding:12px;border:1px solid #d0d5dd;border-radius:9px;font-size:15px}.qr{width:250px;height:250px;object-fit:contain;display:block;margin:10px auto}.note{background:#fff7e6;border-left:4px solid #e4a300;padding:12px;border-radius:7px;font-size:13px;line-height:1.5}.submit{width:100%;padding:14px;background:#0b72ff;color:#fff;border:0;border-radius:10px;font-weight:900;cursor:pointer;margin-top:15px}.success{display:none;background:#eaf8ef;padding:14px;border-radius:9px;margin-top:14px}
footer{background:#07111f;color:#c9d4df;text-align:center;padding:30px}.fine{font-size:12px;color:#8998aa;margin-top:8px}
@media(max-width:850px){.hero{grid-template-columns:1fr;text-align:center}.features{grid-template-columns:1fr 1fr}.products{grid-template-columns:1fr 1fr}.checkout{grid-template-columns:1fr}.navlinks{display:none}}
@media(max-width:480px){.hero h1{font-size:43px}.wrap{padding:45px 4%}}
</style></head><body>
<div class="top">🚚 VX WATCH • Online Order • UPI Payment</div>
<nav class="nav"><div class="brand">VX <span>WATCH</span></div><div class="navlinks"><a href="#features">Features</a><a href="#products">Colours</a><a href="#checkout">Buy</a><a href="admin.php">Admin</a></div><a class="btn dark" href="#checkout">Order Now</a></nav>

<section class="hero"><div><div style="color:#80b7ff;font-weight:800;letter-spacing:2px">VX SMART WATCH</div><h1>Smart look.<br>Smart everyday.</h1><p>VX WATCH — modern smartwatch storefront. अपना colour चुनें और online order करें.</p><div class="price">₹259</div><a class="btn" style="background:#fff;color:#07111f" href="#products">Shop Now</a></div>
<div><div class="watch"><div class="screen">VX WATCH<small>SMART • CONNECTED</small></div></div></div></section>

<section class="wrap" id="features"><h2 class="title">Smart Features</h2><p class="sub">Product information as provided for this store.</p>
<div class="features"><div class="feature">📶<b>5G Connectivity</b><small>SIM support*</small></div><div class="feature">💬<b>WhatsApp</b><small>Smart functions*</small></div><div class="feature">🎨<b>10 Colours</b><small>Choose your colour</small></div><div class="feature">💳<b>UPI Payment</b><small>Scan & pay</small></div></div></section>

<section class="wrap" id="products"><h2 class="title">Choose Your Colour</h2><p class="sub">₹259 per watch</p><div class="products">
<?php foreach($colours as $c): ?>
<div class="product"><div class="visual" style="background:<?=htmlspecialchars($c[1])?>"><div class="mini"><div>VX<br>WATCH</div></div></div><h3><?=htmlspecialchars($c[0])?></h3><div class="row"><b>₹259</b><span>Smart Watch</span></div><button class="add" onclick="choose('<?=htmlspecialchars($c[0],ENT_QUOTES)?>')">Select Colour</button></div>
<?php endforeach; ?></div></section>

<section class="wrap" id="checkout"><h2 class="title">Place Your Order</h2><p class="sub">Payment करें, फिर order details और UTR submit करें.</p>
<div class="checkout"><div class="box"><h3>Delivery Details</h3><form id="orderForm" method="post" action="save_order.php">
<label>Full Name</label><input name="name" required>
<label>Mobile Number</label><input name="phone" required pattern="[0-9]{10}" inputmode="numeric" placeholder="10 digit mobile">
<label>Full Address</label><textarea name="address" required rows="4"></textarea>
<label>Colour</label><select id="colour" name="colour"><?php foreach($colours as $c): ?><option><?=htmlspecialchars($c[0])?></option><?php endforeach; ?></select>
<label>UTR / Transaction ID</label><input name="utr" required placeholder="Payment के बाद UTR">
<button class="submit" type="submit">Place Order — ₹259</button></form></div>
<div class="box"><h3>Pay ₹259 by UPI</h3><div class="note">QR scan करके <b>₹259</b> payment करें। Payment के बाद UTR/Transaction ID भरें.</div><img class="qr" src="upi-qr.jpg" alt="UPI QR"><div class="row"><span>Product</span><b>VX Smart Watch</b></div><hr><div class="row"><span>Price</span><b>₹259</b></div></div></div></section>

<footer><b>VX WATCH</b><br>Smart Watch Store<div class="fine">*Publish connectivity/app claims only after confirming the actual retail unit specifications.</div></footer>
<script>function choose(c){document.getElementById('colour').value=c;document.getElementById('checkout').scrollIntoView({behavior:'smooth'});}</script>
</body></html>