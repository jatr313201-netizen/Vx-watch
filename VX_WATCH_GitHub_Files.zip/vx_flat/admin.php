<?php
session_start();
$PASSWORD='rahul4723@'; // इसे live करने से पहले बदल दें
if(isset($_POST['password'])){ if(hash_equals($PASSWORD,$_POST['password'])) $_SESSION['vx_admin']=true; }
if(isset($_GET['logout'])){session_destroy();header('Location: admin.php');exit;}
if(empty($_SESSION['vx_admin'])){ ?>
<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><title>VX WATCH Admin</title>
<style>body{font-family:Arial;background:#f5f7fb;padding:50px 20px}.box{max-width:380px;margin:auto;background:#fff;padding:25px;border-radius:16px}input,button{width:100%;padding:12px;margin-top:10px}button{background:#07111f;color:#fff;border:0;border-radius:8px;font-weight:800}</style></head><body><div class="box"><h2>VX WATCH Admin</h2><form method="post"><input type="password" name="password" placeholder="Admin password" required><button>Login</button></form></div></body></html>
<?php exit; }
$orders=json_decode(@file_get_contents(__DIR__.'/orders.json'),true); if(!is_array($orders))$orders=[];
usort($orders,function($a,$b){return strcmp($b['created_at'],$a['created_at']);});
?>
<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><title>VX WATCH Orders</title>
<style>body{font-family:Arial;background:#f5f7fb;margin:0;padding:25px}.top{display:flex;justify-content:space-between;align-items:center}.table{background:#fff;border-radius:14px;overflow:auto;margin-top:20px}table{width:100%;border-collapse:collapse;min-width:900px}th,td{padding:12px;border-bottom:1px solid #eee;text-align:left;font-size:13px}th{background:#07111f;color:#fff}.logout{background:#07111f;color:#fff;padding:9px 12px;border-radius:8px;text-decoration:none}.count{font-weight:900;font-size:22px}</style></head>
<body><div class="top"><div><h1>VX WATCH — Orders</h1><div class="count"><?=count($orders)?> total orders</div></div><a class="logout" href="?logout=1">Logout</a></div>
<div class="table"><table><tr><th>Order ID</th><th>Date</th><th>Customer</th><th>Mobile</th><th>Colour</th><th>Address</th><th>UTR</th><th>Amount</th><th>Status</th></tr>
<?php foreach($orders as $o): ?><tr><td><?=htmlspecialchars($o['id'])?></td><td><?=htmlspecialchars($o['created_at'])?></td><td><?=htmlspecialchars($o['name'])?></td><td><?=htmlspecialchars($o['phone'])?></td><td><?=htmlspecialchars($o['colour'])?></td><td><?=htmlspecialchars($o['address'])?></td><td><?=htmlspecialchars($o['utr'])?></td><td>₹<?=htmlspecialchars($o['amount'])?></td><td><?=htmlspecialchars($o['status'])?></td></tr><?php endforeach; ?>
</table></div></body></html>