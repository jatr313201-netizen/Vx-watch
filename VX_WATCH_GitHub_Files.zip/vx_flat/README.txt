VX WATCH live PHP website files.
Upload all files to the repository root.
Admin: /admin.php
Password: rahul4723@
