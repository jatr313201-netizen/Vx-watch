<?php
header('Content-Type: text/html; charset=utf-8');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: index.php'); exit; }
function clean($v){ return trim(preg_replace('/[\r\n\t]+/',' ', $v ?? '')); }
$name=clean($_POST['name']); $phone=clean($_POST['phone']); $address=clean($_POST['address']);
$colour=clean($_POST['colour']); $utr=clean($_POST['utr']);
if(!$name || !preg_match('/^[0-9]{10}$/',$phone) || !$address || !$colour || !$utr){
  die('<h2>Invalid order details</h2><p><a href="index.php#checkout">Go back</a></p>');
}
$file=__DIR__.'/orders.json';
$orders=json_decode(@file_get_contents($file),true); if(!is_array($orders))$orders=[];
$order=[
 'id'=>'VX-'.date('YmdHis').'-'.random_int(100,999),
 'created_at'=>date('Y-m-d H:i:s'),'name'=>$name,'phone'=>$phone,'address'=>$address,
 'colour'=>$colour,'utr'=>$utr,'amount'=>259,'status'=>'Payment verification pending'
];
$orders[]=$order;
file_put_contents($file,json_encode($orders,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE),LOCK_EX);
?>
<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><title>Order Received</title>
<style>body{font-family:Arial;background:#f5f7fb;text-align:center;padding:60px 20px}.box{max-width:520px;margin:auto;background:#fff;padding:35px;border-radius:18px;box-shadow:0 8px 30px #0001}h1{color:#087f3f}.id{font-size:22px;font-weight:900;margin:15px}.btn{display:inline-block;background:#07111f;color:#fff;padding:12px 18px;border-radius:9px;text-decoration:none;font-weight:800}</style></head>
<body><div class="box"><h1>Order Received ✓</h1><p>आपका order वेबसाइट में save हो गया है.</p><div class="id"><?=htmlspecialchars($order['id'])?></div><p>Payment verification के बाद order process किया जा सकता है.</p><a class="btn" href="index.php">Back to VX WATCH</a></div></body></html>